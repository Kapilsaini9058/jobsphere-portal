import { useState, useEffect } from "react";

function App() {

  const [page, setPage] = useState("home");



  const [jobs, setJobs] = useState([
    {
      title: "Java Developer",
      company: "Infosys",
      location: "Delhi",
      salary: "6 LPA"
    },
    {
          title: "Java Developer",
          company: "Infosys",
          location: "Delhi",
          salary: "6 LPA"
        },
        {
              title: "Java Developer",
              company: "Infosys",
              location: "Delhi",
              salary: "6 LPA"
            },
    {
      title: "Frontend Developer",
      company: "TCS",
      location: "Mumbai",
      salary: "8 LPA"
    },
    {
          title: "Frontend Developer",
          company: "TCS",
          location: "Mumbai",
          salary: "8 LPA"
        },
        {
              title: "Frontend Developer",
              company: "TCS",
              location: "Mumbai",
              salary: "8 LPA"
            },
    {
      title: "Full Stack Developer",
      company: "Wipro",
      location: "Bangalore",
      salary: "10 LPA"
    },
     {
          title: "react Stack Developer",
          company: "Wipro",
          location: "Bangalore",
          salary: "10 LPA"
        },
         {
              title: "python Stack Developer",
              company: "Wipro",
              location: "Bangalore",
              salary: "10 LPA"
            }
  ]);

  const [jobTitle, setJobTitle] = useState("");
    const [company, setCompany] = useState("");
  const [location, setLocation] = useState("");
    const [salary, setSalary] = useState("");


  const [search, setSearch] = useState("");
  const [searchLocation, setSearchLocation] = useState("");



  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const [loginEmail, setLoginEmail] = useState("");
  const [loginPassword, setLoginPassword] = useState("");

  const [loggedInUser, setLoggedInUser] = useState("");


  useEffect(() => {

    const user = localStorage.getItem("loggedInUser");

    if (user) {
      setLoggedInUser(user);
    }

  }, []);






  const addJob = () => {

    if (
      jobTitle === "" ||
      company === "" ||
      location === "" ||
      salary === ""
    ) {
      alert("Please fill all fields");
      return;
    }

    const newJob = {
      title: jobTitle,
      company: company,
      location: location,
      salary: salary
    };

    setJobs([...jobs, newJob]);

    alert("Job Posted Successfully");

    setJobTitle("");
    setCompany("");
    setLocation("");
    setSalary("");
  };



  const deleteJob = (index) => {

    const updatedJobs = jobs.filter(
      (_, i) => i !== index
    );

    setJobs(updatedJobs);
  };


  const registerUser = () => {

    if (
      name === "" ||
      email === "" ||
      password === ""
    ) {
      alert("Please fill all fields");
      return;
    }

    const users =
      JSON.parse(localStorage.getItem("users")) || [];

    const existingUser = users.find(
      (u) => u.email === email
    );

    if (existingUser) {
      alert("User already exists");
      return;
    }

    const newUser = {
      name,
      email,
      password
    };

    const updatedUsers = [...users, newUser];

    localStorage.setItem(
      "users",
      JSON.stringify(updatedUsers)
    );

    alert("Registration Successful");

    setName("");
    setEmail("");
    setPassword("");

    setPage("login");
  };



  const loginUser = () => {

    const users =
      JSON.parse(localStorage.getItem("users")) || [];

    const user = users.find(
      (u) =>
        u.email === loginEmail &&
        u.password === loginPassword
    );

    if (user) {

      localStorage.setItem(
        "loggedInUser",
        user.name
      );

      setLoggedInUser(user.name);

      alert("Login Successful");

      setPage("home");

    } else {

      alert("Invalid Email or Password");
    }
  };



  const logoutUser = () => {

    localStorage.removeItem("loggedInUser");

    setLoggedInUser("");

    alert("Logout Successful");
  };


  const filteredJobs = jobs.filter((job) => {

    return (
      job.title.toLowerCase().includes(search.toLowerCase()) &&
      job.location.toLowerCase().includes(searchLocation.toLowerCase())
    );
  });

  return (

    <div>



      <nav className="navbar navbar-expand-lg navbar-dark bg-dark shadow">

        <div className="container">

          <a className="navbar-brand fw-bold fs-3" href="#">
            JobSphere
          </a>

          <div className="d-flex flex-wrap">

            <button
              className="btn btn-light me-2 mb-2"
              onClick={() => setPage("home")}
            >
              Home
            </button>

            <button
              className="btn btn-primary me-2 mb-2"
              onClick={() => setPage("login")}
            >
              Login
            </button>

            <button
              className="btn btn-warning me-2 mb-2"
              onClick={() => setPage("register")}
            >
              Register
            </button>

            <button
              className="btn btn-success me-2 mb-2"
              onClick={() => setPage("postjob")}
            >
              Employer
            </button>

            <button
              className="btn btn-danger me-2 mb-2"
              onClick={() => setPage("admin")}
            >
              Admin
            </button>

            {loggedInUser && (

              <button
                className="btn btn-secondary mb-2"
                onClick={logoutUser}
              >
                Logout
              </button>
            )}

          </div>

        </div>

      </nav>



      {loggedInUser && (

        <div className="bg-light p-3 text-center shadow-sm">

          <h5>
            Welcome, {loggedInUser}
          </h5>

        </div>
      )}


      {page === "home" && (

        <div className="container mt-5">

          <div className="text-center mb-5">

            <h1 className="display-4 fw-bold">
              Find Your Dream Job
            </h1>

            <p className="text-muted">
              Search and apply to top companies
            </p>

          </div>



          <div className="row mb-5">

            <div className="col-md-5 mb-3">

              <input
                type="text"
                placeholder="Search Job Title"
                className="form-control"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />

            </div>

            <div className="col-md-5 mb-3">

              <input
                type="text"
                placeholder="Search Location"
                className="form-control"
                value={searchLocation}
                onChange={(e) => setSearchLocation(e.target.value)}
              />

            </div>

            <div className="col-md-2 mb-3">

              <button className="btn btn-primary w-100">
                Search
              </button>

            </div>

          </div>



          <div className="row">

            {filteredJobs.map((job, index) => (

              <div className="col-md-4 mb-4" key={index}>

                <div className="card shadow border-0 p-3 h-100">

                  <h4 className="fw-bold">
                    {job.title}
                  </h4>

                  <h6 className="text-primary">
                    {job.company}
                  </h6>

                  <p>
                    📍 {job.location}
                  </p>

                  <p>
                    💰 {job.salary}
                  </p>

                  <button className="btn btn-success">
                    Apply Now
                  </button>

                </div>

              </div>

            ))}

          </div>

        </div>
      )}



      {page === "login" && (

        <div className="container mt-5">

          <div className="card shadow p-4 col-md-5 mx-auto border-0">

            <h2 className="text-center mb-4">
              Candidate Login
            </h2>

            <input
              type="email"
              placeholder="Enter Email"
              className="form-control mb-3"
              value={loginEmail}
              onChange={(e) => setLoginEmail(e.target.value)}
            />

            <input
              type="password"
              placeholder="Enter Password"
              className="form-control mb-3"
              value={loginPassword}
              onChange={(e) => setLoginPassword(e.target.value)}
            />

            <button
              className="btn btn-primary w-100"
              onClick={loginUser}
            >
              Login
            </button>

          </div>

        </div>
      )}


      {page === "register" && (

        <div className="container mt-5">

          <div className="card shadow p-4 col-md-6 mx-auto border-0">

            <h2 className="text-center mb-4">
              Candidate Registration
            </h2>

            <input
              type="text"
              placeholder="Full Name"
              className="form-control mb-3"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />

            <input
              type="email"
              placeholder="Email"
              className="form-control mb-3"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />

            <input
              type="password"
              placeholder="Password"
              className="form-control mb-3"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />

            <input
              type="text"
              placeholder="Skills"
              className="form-control mb-3"
            />

            <input
              type="file"
              className="form-control mb-3"
            />

            <button
              className="btn btn-warning w-100"
              onClick={registerUser}
            >
              Register
            </button>

          </div>

        </div>
      )}



      {page === "postjob" && (

        <div className="container mt-5">

          <div className="card shadow p-4 col-md-6 mx-auto border-0">

            <h2 className="text-center mb-4">
              Employer Dashboard
            </h2>

            <input
              type="text"
              placeholder="Job Title"
              className="form-control mb-3"
              value={jobTitle}
              onChange={(e) => setJobTitle(e.target.value)}
            />

            <input
              type="text"
              placeholder="Company Name"
              className="form-control mb-3"
              value={company}
              onChange={(e) => setCompany(e.target.value)}
            />

            <input
              type="text"
              placeholder="Location"
              className="form-control mb-3"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
            />

            <input
              type="text"
              placeholder="Salary"
              className="form-control mb-3"
              value={salary}
              onChange={(e) => setSalary(e.target.value)}
            />

            <input
              type="text"
              placeholder="Skills Required"
              className="form-control mb-3"
            />

            <button
              className="btn btn-success w-100"
                   onClick={addJob}
            >
              Post Job
            </button>

          </div>

        </div>
      )}



      {page === "admin" && (

        <div className="container mt-5">

          <div className="card shadow p-4 border-0">

            <h2 className="text-center mb-4">
              Admin Panel
            </h2>
<button
  className="btn btn-success mb-3"
  onClick={() => setPage("postjob")}
>
  Add New Job
</button>
            <table className="table table-bordered table-hover">

              <thead className="table-dark">

                <tr>
                  <th>Job</th>
                  <th>Company</th>
                  <th>Location</th>
                  <th>Salary</th>
                  <th>Action</th>
                </tr>

              </thead>

                   <tbody>

                {jobs.map((job, index) => (

                  <tr key={index}>

                    <td>{job.title}</td>
                    <td>{job.company}</td>
                    <td>{job.location}</td>
                    <td>{job.salary}</td>

                    <td>

                      <button
                        className="btn btn-danger btn-sm"
                        onClick={() => deleteJob(index)}
                      >
                        Delete
                      </button>

                    </td>

                  </tr>

                ))}

              </tbody>

            </table>

          </div>

        </div>
      )}
<footer className="bg-dark text-white text-center p-3 mt-5">
  <h5>JobSphere - Smart Recruitment Portal</h5>

  <p className="mb-0">
    Developed By Mr. Kapil Saini (Full Stack Developer)
  </p>
</footer>
    </div>
  );
}

export default App;